<?php
define('IN_ADMIN', true);
include("../includes/common.php");
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

if(!checkRefererHost())exit('{"code":403}');

if(in_array($act, ['set', 'setUserEnable', 'saveUserInfo', 'delUser'], true)){
	require_post_request();
	require_csrf_token();
}

@header('Content-Type: application/json; charset=UTF-8');

switch($act){
case 'getcount':
	$thtime=date("Y-m-d").' 00:00:00';
	$lastday=date("Y-m-d",strtotime("-1 day")).' 00:00:00';
	$count1=$DB->getColumn("SELECT count(*) from pre_file WHERE deleted_at IS NULL");
	$count2=$DB->getColumn("SELECT count(*) from pre_file WHERE deleted_at IS NULL AND addtime>='$thtime'");
	$count3=$DB->getColumn("SELECT count(*) from pre_file WHERE deleted_at IS NULL AND addtime>='$lastday' AND addtime<'$thtime'");
	$count4=$DB->getColumn("SELECT count(*) from pre_user");

	$result=["code"=>0,"count1"=>$count1,"count2"=>$count2,"count3"=>$count3,"count4"=>$count4];
	exit(json_encode($result));
break;
case 'set':
	if(array_key_exists('site_url', $_POST)){
		$site_url = pan_normalize_site_url($_POST['site_url']);
		if($site_url === false)exit('{"code":-1,"msg":"站点外链地址格式不正确"}');
		$_POST['site_url'] = $site_url;
	}
	foreach(['webdav_endpoint', 'webdav_public_url'] as $urlKey){
		if(isset($_POST[$urlKey])){
			$_POST[$urlKey] = rtrim(trim($_POST[$urlKey]), '/');
			if($_POST[$urlKey] !== ''){
				$scheme = strtolower((string)parse_url($_POST[$urlKey], PHP_URL_SCHEME));
				if(!filter_var($_POST[$urlKey], FILTER_VALIDATE_URL) || !in_array($scheme, ['http', 'https'], true)){
					exit(json_encode(['code'=>-1, 'msg'=>'WebDAV 地址格式不正确']));
				}
			}
		}
	}
	if(isset($_POST['webdav_root'])) $_POST['webdav_root'] = trim(str_replace('\\', '/', $_POST['webdav_root']), '/');
	if(isset($_POST['access_log_retention_days'])) $_POST['access_log_retention_days'] = max(1, min(3650, intval($_POST['access_log_retention_days'])));
	if(isset($_POST['user_quota_bytes_mb'])){
		$_POST['user_quota_bytes'] = max(0, intval(floatval($_POST['user_quota_bytes_mb']) * 1048576));
		unset($_POST['user_quota_bytes_mb']);
	}
	if(isset($_POST['user_daily_upload_bytes_mb'])){
		$_POST['user_daily_upload_bytes'] = max(0, intval(floatval($_POST['user_daily_upload_bytes_mb']) * 1048576));
		unset($_POST['user_daily_upload_bytes_mb']);
	}
	if(isset($_POST['user_quota_files'])) $_POST['user_quota_files'] = max(0, intval($_POST['user_quota_files']));
	if(isset($_POST['green_label_porn'])){
		$_POST['green_label_porn'] = implode(',',$_POST['green_label_porn']);
	}
	if(isset($_POST['green_label_terrorism'])){
		$_POST['green_label_terrorism'] = implode(',',$_POST['green_label_terrorism']);
	}
	foreach($_POST as $k=>$v){
		saveSetting($k, $v);
	}
	pan_audit_admin_action($DB, $conf['admin_user'], 'settings_updated', 'settings', '', ['fields'=>array_values(array_filter(array_keys($_POST), function($key){ return $key !== 'csrf_token'; }))]);
	exit('{"code":0,"msg":"succ"}');
break;
case 'iptype':
	$result = [
	['name'=>'0_X_FORWARDED_FOR', 'ip'=>real_ip(0), 'city'=>get_ip_city(real_ip(0))],
	['name'=>'1_X_REAL_IP', 'ip'=>real_ip(1), 'city'=>get_ip_city(real_ip(1))],
	['name'=>'2_REMOTE_ADDR', 'ip'=>real_ip(2), 'city'=>get_ip_city(real_ip(2))]
	];
	exit(json_encode($result));
break;
case 'userList':
	$conditions=['1=1'];
	$params=[];
	$type_arr = ['qq'=>'QQ','wx'=>'微信','google'=>'Google','apple'=>'Apple'];
	if(isset($_POST['dstatus']) && $_POST['dstatus']>-1) {
		$dstatus = intval($_POST['dstatus']);
		$conditions[]='`enable`=:enable';
		$params[':enable']=$dstatus;
	}
	if(isset($_POST['kw']) && !empty($_POST['kw'])) {
		$type = intval($_POST['type']);
		$kw = trim($_POST['kw']);
		if($type == 1){
			$conditions[]='`uid`=:uid';
			$params[':uid']=intval($kw);
		}elseif($type == 2){
			$conditions[]='`openid`=:openid';
			$params[':openid']=$kw;
		}elseif($type == 3){
			$conditions[]='`nickname` LIKE :kw';
			$params[':kw']='%'.$kw.'%';
		}elseif($type == 4){
			$conditions[]='`loginip`=:loginip';
			$params[':loginip']=$kw;
		}
	}
	$offset = max(0, intval($_POST['offset']));
	$limit = min(100, max(1, intval($_POST['limit'])));
	$sql = implode(' AND ', $conditions);
	$total = $DB->getColumn("SELECT count(*) from pre_user WHERE {$sql}", $params);
	$list = $DB->getAll("SELECT * FROM pre_user WHERE {$sql} order by uid desc limit $offset,$limit", $params);
	$list2 = [];
	foreach($list as $row){
		$row['type'] = isset($type_arr[$row['type']]) ? $type_arr[$row['type']] : $row['type'];
		$list2[] = $row;
	}

	exit(json_encode(['total'=>$total, 'rows'=>$list2]));
break;
case 'setUserEnable':
	$uid=intval($_POST['uid']);
	$enable=intval($_POST['enable']);
	$sql = "UPDATE pre_user SET enable='$enable' WHERE uid='$uid'";
	if($DB->exec($sql)!==false){ pan_audit_admin_action($DB, $conf['admin_user'], $enable ? 'user_enabled' : 'user_disabled', 'user', $uid); exit('{"code":0,"msg":"修改用户成功！"}'); }
	else exit('{"code":-1,"msg":"修改用户失败['.$DB->error().']"}');
break;
case 'saveUserInfo':
	$uid=intval($_POST['uid']);
	$level=intval($_POST['level']);
	$sql = "UPDATE pre_user SET level='$level' WHERE uid='$uid'";
	if($DB->exec($sql)!==false){ pan_audit_admin_action($DB, $conf['admin_user'], 'user_level_updated', 'user', $uid); exit('{"code":0,"msg":"修改用户成功！"}'); }
	else exit('{"code":-1,"msg":"修改用户失败['.$DB->error().']"}');
break;
case 'delUser':
	$uid=intval($_POST['uid']);
	$row=$DB->getRow("select * from pre_user where uid='$uid' limit 1");
	if(!$row)
		exit('{"code":-1,"msg":"当前用户不存在！"}');
	$sql = "DELETE FROM pre_user WHERE uid='$uid'";
	if($DB->exec($sql)){ pan_audit_admin_action($DB, $conf['admin_user'], 'user_deleted', 'user', $uid); exit('{"code":0,"msg":"删除用户成功！"}'); }
	else exit('{"code":-1,"msg":"删除文件失败['.$DB->error().']"}');
break;
default:
	exit('{"code":-4,"msg":"No Act"}');
break;
}
